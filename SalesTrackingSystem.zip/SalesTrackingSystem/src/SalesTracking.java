/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author JacksonKevin
 */
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class SalesTracking {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<SalesPerson> salesPeople = new ArrayList<>();

        // Collect data for 3 salespeople
        for (int i = 0; i < 3; i++) {
            System.out.println("Enter salesperson's name:");
            String name = scanner.nextLine();

            System.out.println("Enter salesperson's title:");
            String title = scanner.nextLine();

            SalesPerson person = new SalesPerson(name, title);

            System.out.println("How many sales values will you enter for " + name + "?");
            int numSales = scanner.nextInt();

            for (int j = 0; j < numSales; j++) {
                System.out.println("Enter sale " + (j + 1) + " for " + name + ":");
                person.addSale(scanner.nextDouble());
            }

            scanner.nextLine(); // Consume leftover newline
            salesPeople.add(person);
        }

        scanner.close(); // Close the scanner to free resources

        // Generate and print the sales report
        generateSalesReport(salesPeople);
    }

    // Report generation method
    public static void generateSalesReport(ArrayList<SalesPerson> salesPeople) {
        double companyTotal = 0; // Variable to track total sales for the company

        // Loop through each salesperson in the list
        for (SalesPerson person : salesPeople) {
            Iterator<Double> salesIterator = person.iterSales();

            double total = 0; // Total sales for the salesperson
            double min = Double.MAX_VALUE; // Initialize min to the highest possible value
            double max = Double.MIN_VALUE; // Initialize max to the lowest possible value
            int count = 0; // Counter for number of sales

            // Iterate over sales values
            while (salesIterator.hasNext()) {
                double sale = salesIterator.next();
                total += sale; // Add sale to total
                if (sale < min) min = sale; // Check for minimum sale
                if (sale > max) max = sale; // Check for maximum sale
                count++;
            }

            double average = total / count; // Calculate average sales
            companyTotal += total; // Add to company-wide total

            // Print report for the salesperson
            System.out.printf("Salesperson: %s%n", person.getName());
            System.out.printf("Total Sales: $%.2f%n", total);
            System.out.printf("Min Sale: $%.2f%n", min);
            System.out.printf("Max Sale: $%.2f%n", max);
            System.out.printf("Average Sale: $%.2f%n", average);
            System.out.println("----------------------------------------------------");
        }

        // Print total sales for the company
        System.out.printf("Company Total Sales: $%.2f%n", companyTotal);
    }
}
